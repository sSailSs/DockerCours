# Docker : compréhension des concepts et architecture

## 🐳 Qu'est-ce que Docker ?

Docker permet de lancer des applications dans des **conteneurs** isolés (comme des mini-ordinateurs virtuels légers).

- **Image** : modèle pré-configuré (ex: WordPress, MySQL, Alpine)
- **Conteneur** : instance d'une image en cours d'exécution
- **Volume** : espace de stockage pour les données persistantes
- **docker-compose** : outil pour orchestrer plusieurs conteneurs

---

## 1. Conteneur vs Machine virtuelle

### Différence conceptuelle

Les machines virtuelles et les conteneurs permettent d'isoler des applications de l'infrastructure physique, mais leur fonctionnement est différent.

**Machine Virtuelle (VM) :**
- Copie complète d'une machine physique
- Embarque son propre système d'exploitation + application
- Plus lourde en ressources, mais très isolée

**Conteneur :**
- Pas d'OS complet
- Partage le noyau du système hôte
- Embarque uniquement l'application et ses dépendances
- Plus léger, plus rapide à démarrer, plus facile à déployer

### Ce que partage un conteneur avec l'hôte

Un conteneur partage avec l'hôte **le noyau du système d'exploitation**.

Contrairement à une VM, un conteneur ne possède pas son propre OS complet. Il utilise le noyau de l'OS de la machine hôte pour gérer :
- Les processus
- La mémoire
- Le réseau
- Le système de fichiers

### Ce qu'isole un conteneur

Un conteneur isole l'environnement d'exécution de l'application par rapport aux autres conteneurs et au système hôte.

Il isole notamment :
- **Les processus** : chaque conteneur a ses propres processus
- **Le système de fichiers** : rootfs isolé
- **Le réseau** : IP et ports virtuels
- **Les variables d'environnement** : propres à chaque conteneur

Chaque conteneur fonctionne comme s'il était seul sur la machine, même s'il partage le noyau avec l'hôte. Cette isolation évite les conflits entre applications et garantit un environnement maîtrisé et reproductible.

### Avantages et inconvénients

#### Machines Virtuelles

**Avantages :**
- ✅ Isolation très forte (OS dédié)
- ✅ Possibilité d'OS différents (Windows, Linux, macOS)
- ✅ Sécurité élevée entre les environnements
- ✅ Cloisonnement strict des ressources

**Inconvénients :**
- ❌ Consommation élevée de ressources (CPU, RAM, disque)
- ❌ Démarrage plus lent
- ❌ Maintenance lourde (mise à jour de chaque OS)
- ❌ Moins flexible pour le déploiement rapide

#### Conteneurs

**Avantages :**
- ✅ Très légers et économes en ressources
- ✅ Démarrage ultra-rapide
- ✅ Déploiement et portabilité facilités
- ✅ Environnements reproductibles
- ✅ Parfaits pour les microservices

**Inconvénients :**
- ❌ Isolation moins forte (noyau partagé)
- ❌ Dépendance au système d'exploitation de l'hôte
- ❌ Sécurité potentiellement plus sensible si mal configurée

### Quand préférer l'un ou l'autre

**Quand utiliser une Machine Virtuelle :**
- Besoin d'un OS différent de celui de l'hôte
- Exigence d'isolation très forte (sécurité critique)
- Applications legacy nécessitant un OS spécifique
- Production critique nécessitant un cloisonnement strict
- Besoin de reproduire une machine complète (OS + applications)

**Quand utiliser un Conteneur :**
- Déploiement rapide d'applications
- Besoin de légèreté et d'optimisation des ressources
- Environnements de développement et de test
- Architectures microservices
- Applications modernes cloud-native
- Besoin de portabilité entre environnements (dev, test, prod)

### Tableau comparatif

| Critère | Machine Virtuelle | Conteneur |
|---------|------------------|-----------|
| **Taille** | Plusieurs Go | Quelques Mo/100s Mo |
| **Démarrage** | Quelques minutes | Quelques ms/secondes |
| **Isolation** | Très forte | Forte |
| **Consommation** | Élevée | Très basse |
| **OS** | Plusieurs possibles | Noyau partagé |
| **Portabilité** | Moyenne | Très élevée |

### Architecture : VMs vs Containers

![Comparaison architecture : Virtual Machines vs Containers](./Photos/VMvsDocker.png)

**Visualisation :**
- **Gauche (VMs)** : Chaque VM embarque son propre OS Guest, consomme beaucoup de ressources
- **Droite (Containers)** : Tous les containers partagent le même système d'exploitation via le Container Engine
- **Différence clé** : VMs utilisent un Hyperviseur, Containers utilisent le système d'exploitation hôte directement

---

## 2. Image vs Conteneur

### Définitions

**Image Docker :**
- Modèle statique, immuable et versionné
- Contient tous les fichiers, librairies et configurations nécessaires pour une application
- Stockée dans un registry (Docker Hub, privé, etc.)

**Conteneur Docker :**
- Instance en cours d'exécution d'une image
- Processus vivant et temporaire
- Peut écrire des données et modifier son système de fichiers (couche d'écriture)

### La relation Image → Conteneur

- **1 image** → **N conteneurs** : une même image peut générer plusieurs conteneurs
- **L'image est le blueprint** : elle définie l'architecture de base
- **Le conteneur est l'instance** : il exécute réellement l'image

**Analogie :**
- Image = Class en programmation
- Conteneur = Instance (objet) d'une classe

### Immutabilité de l'image

Une image Docker est **immuable** : une fois construite, elle ne change jamais.

Cela signifie :
- ✅ Reproductibilité : même image = même résultat
- ✅ Traçabilité : on sait exactement ce qui est déployé
- ✅ Sécurité : pas de dérive silencieuse en production
- ✅ Fiabilité : pas de "ça marche chez moi mais pas en prod"

### Le cycle de vie `docker run`

```
Image (statique)
    ↓
docker run → Conteneur (actif)
    ↓
[Application s'exécute]
    ↓
docker stop → Conteneur (arrêté)
    ↓
docker rm → Conteneur (supprimé)
```

Quand un conteneur est supprimé sans volume, les données locales disparaissent définitivement.

---

## 3. Build vs Run

### `docker build` : fabriquer l'image

`docker build` crée une image à partir d'un Dockerfile.

**Processus :**
1. Lire le Dockerfile ligne par ligne
2. Exécuter chaque instruction (FROM, RUN, COPY, etc.)
3. Créer des couches successives
4. Produire une image finale

**Exemple :**
```bash
docker build -t mon-appli:1.0 .
# Crée une image 'mon-appli' avec le tag '1.0'
```

**Caractéristiques :**
- ✅ Étape de création/fabrication
- ✅ Produit une image immuable
- ✅ Prend du temps (compilation, téléchargement)
- ✅ Résultat reproductible (si Dockerfile bien écrit)

### `docker run` : déployer le conteneur

`docker run` lance un conteneur à partir d'une image.

**Processus :**
1. Télécharger l'image (si nécessaire)
2. Créer un conteneur
3. Ajouter une couche d'écriture
4. Lancer le processus principal

**Exemple :**
```bash
docker run -d -p 8080:80 mon-appli:1.0
# Lance un conteneur en arrière-plan, map port 8080 sur 80
```

**Caractéristiques :**
- ✅ Étape de déploiement/exécution
- ✅ Lance une instance éphémère
- ✅ Très rapide
- ✅ Peut être répété N fois

### Séparation des responsabilités

| Phase | Outil | Rôle |
|-------|-------|------|
| **Build** | Dockerfile + `docker build` | Définir et créer l'image |
| **Run** | `docker run` | Exécuter un conteneur |

Cette séparation permet :
- ✅ De construire une fois, déployer partout
- ✅ Une meilleure traçabilité
- ✅ Une optimisation des ressources

### Qu'est-ce qu'on met dans une image

Une image contient :
- Une image de base (FROM ubuntu, FROM python:3.11, etc.)
- Des dépendances installées (packages, libraries)
- Des fichiers applicatifs (code source)
- Des configurations
- Un point d'entrée (CMD ou ENTRYPOINT)

**Ce qu'on ne met PAS dans l'image :**
- ❌ Les données applicatives (utiliser des volumes)
- ❌ Les secrets (utiliser des variables d'environnement ou Docker Secrets)
- ❌ Les logs (utiliser un driver de log)

### Pourquoi cette séparation

1. **Immuabilité** : une image ne change pas, seule la version change
2. **Réutilisabilité** : même image en dev, test, prod
3. **Sécurité** : pas de modification directe en production
4. **Infrastructure as Code** : tout est versionné et reproductible
5. **CI/CD** : facile d'automatiser build et déploiement

---

## 4. Les layers (couches) d'images Docker

### Qu'est-ce qu'une couche

Une couche est une **diff** (différence) du système de fichiers.

Chaque instruction du Dockerfile génère une couche :
```dockerfile
FROM ubuntu:22.04          # Couche 1 : image de base
RUN apt-get update         # Couche 2 : modifications
RUN apt-get install -y git # Couche 3 : ajout de packages
COPY app /app              # Couche 4 : ajout de fichiers
```

### Comment les couches s'empilent

Les couches sont **empilées** les unes sur les autres (like a stack of pancakes):

![Architecture des couches Docker](./Photos/dockerLayer.png)

**Visualisation :**
- **Base Image** : l'image de départ (ex: Debian, Ubuntu)
- **Couches successives** : chaque instruction du Dockerfile crée une couche (add Debian, add emacs, add Apache)
- **Image** : la combinaison de toutes les couches parentes
- **Container** : le conteneur ajoute une couche writable au-dessus de l'image immuable
- **Kernel/bootfs** : le noyau du système hôte

Chaque couche est immuable et peut être réutilisée par d'autres images.

### Le mécanisme de cache

Docker met en cache les couches pour accélérer les builds.

**Si rien ne change :**
```bash
docker build .  # Build 1 : 30 secondes
docker build .  # Build 2 : 1 seconde (couches en cache)
```

**Si une ligne change :**
```dockerfile
RUN apt-get install -y git  # Change
RUN apt-get install -y curl # Toutes les couches suivantes
```

**Ordre optimal :**
```dockerfile
# ❌ Inefficace
COPY app /app              # Fréquemment modifié
RUN apt-get install -y git # En cache, mais rebuild à chaque changement app

# ✅ Efficace
RUN apt-get install -y git # Rarement modifié, réutilisable
COPY app /app              # Fréquemment modifié, invalidation locale
```

### Optimisation et performance

**Réduire la taille de l'image :**
- Utiliser des images de base petites (Alpine, Distroless)
- Nettoyer après les installations : `apt-get clean && rm -rf /var/lib/apt/lists/*`
- Utiliser les builds multi-étapes

**Accélérer les builds :**
- Placer les instructions stables avant les instables
- Regrouper les `RUN` avec `&&` : `RUN apt-get update && apt-get install -y git`
- Utiliser `.dockerignore` pour éviter les copies inutiles

**Impact sur la performance :**
- Plus de couches = plus d'overhead au démarrage (minimal)
- Mais : moins de couches = moins de cache, builds plus longs

---

## 5. Qu'est-ce qu'un registry Docker

### Qu'est-ce qu'un registry

Un registry est un **serveur centralisé** qui stocke et distribue les images Docker.

C'est au registry ce que GitHub est au code source :
- **Stockage centralisé** des images
- **Versioning** et **tagging**
- **Partage** entre développeurs et serveurs
- **Sécurité** avec authentification et autorisations

### Le cycle du registry Docker

![Cycle Docker Registry - Build, Commit, Push, Pull](./Photos/DockerRegistry.webp)

**Le flux montre :**
- **Gauche (Développement)** : Build Image → Commit Image → Push Image vers le registry
- **Centre** : Docker Registry/Hub (point centralisé)
- **Droite (Déploiement)** : Pull Image depuis le registry

### Docker Hub vs Registry privé

**Docker Hub (public) :**
- Service public et gratuit fourni par Docker
- Contient des images officielles et communautaires
- Accessible à tous
- Parfait pour les projets open-source

**Registry privé :**
- Hébergé en interne ou dans le cloud
- Contient des images confidentielles ou propriétaires
- Accès contrôlé par authentification
- Obligatoire pour les données sensibles

### À quoi ça sert concrètement

Un registry sert à :

- ✅ **Centraliser les images Docker** en un seul endroit
- ✅ **Partager les images** entre développeurs, serveurs et environnements
- ✅ **Versionner les images** (tag, versions multiples)
- ✅ **Automatiser les déploiements** dans les pipelines CI/CD

**Analogie :**
- **Registry** = dépôt centralisé pour images (comme GitHub pour le code)
- **Image** = artefact versionné
- **Tag** = branche ou version

### La différence entre `docker pull` et `docker build`

![Cycle complet Docker - du Dockerfile au Container](./Photos/DockerHub.jpg)

#### `docker build`

- ✅ **Construit** une image **localement** à partir d'un Dockerfile
- ✅ Crée une nouvelle image sur la machine
- ✅ Prend du temps (compilation, installation)

**Exemple :**
```bash
docker build -t mon-appli:1.0 .
# Construit localement depuis le Dockerfile
```

#### `docker pull`

- ✅ **Télécharge** une image **existante** depuis un registry
- ✅ Ne construit rien : récupère une image prête à l'emploi
- ✅ Très rapide (juste un téléchargement)

**Exemple :**
```bash
docker pull ubuntu:22.04
# Télécharge depuis Docker Hub
```

**Visualisation du flux :**
Le diagramme ci-dessus montre le cycle complet : Dockerfile → Build → Image → Push vers Docker Hub → Pull → Run → Container

### Pourquoi c'est indispensable en équipe

Dans un contexte professionnel, un registry est **indispensable** car il permet :

- ✅ **Cohérence** : partager exactement les mêmes images entre tous les membres
- ✅ **Conformité** : assurer l'identité entre dev, test, recette et production
- ✅ **Sécurité** : contrôler l'accès aux images internes
- ✅ **Automatisation** : intégrer Docker dans des pipelines CI/CD
- ✅ **Traçabilité** : versionner et auditer les déploiements

**Problème sans registry :**
```
Dev A → docker build → Image v1.0 (locale)
Dev B → docker build → Image v1.0 (différente !)
Prod → docker pull → Laquelle utiliser ?
Résultat : chaos et bugs imprévisibles
```

**Solution avec registry :**
```
Tous → docker pull Mon-Registry/mon-appli:1.0
Résultat : identité garantie partout
```

### Exemple d'utilisation d'un registry privé

**Login au registry :**
```bash
docker login my-registry.company.com
# Utilise les credentials pour accéder
```

**Pusher une image :**
```bash
docker tag mon-appli:1.0 my-registry.company.com/mon-appli:1.0
docker push my-registry.company.com/mon-appli:1.0
# Image stockée sur le registry privé
```

**Récupérer depuis le registry :**
```bash
docker pull my-registry.company.com/mon-appli:1.0
# Télécharge depuis le registry privé
```

---

## 6. Le concept d'infrastructure immuable

### Ce que veut dire "on ne modifie pas un serveur en production"

Dire qu'on ne modifie pas un serveur en production signifie que l'on n'applique pas de changements directement sur un serveur déjà en fonctionnement (pas d'installation manuelle, pas de correctif appliqué à la main, pas de modification de configuration en direct).

À la place, toute modification passe par la création d'une nouvelle version de l'infrastructure ou de l'application, qui est ensuite redéployée.

### Ce que ça change par rapport à l'administration système classique

Dans une administration système classique, on se connecte sur les serveurs pour :

- Installer des paquets
- Modifier des fichiers de configuration
- Appliquer des correctifs directement

Avec une infrastructure immuable, on ne corrige pas un serveur existant. On recrée une nouvelle version à partir d'une configuration définie (images, scripts, infrastructure as code), puis on remplace l'ancienne.

### En quoi Docker pousse naturellement vers ce modèle

Docker pousse vers ce modèle car :

- Les images sont immuables
- Les conteneurs sont jetables
- Toute modification passe par un nouveau `docker build`

On ne modifie pas un conteneur pour corriger un problème : on reconstruit une nouvelle image, puis on redéploie un nouveau conteneur basé sur cette image.

### Avantages en termes de fiabilité et de reproductibilité

Ce modèle apporte :

- ✅ **Fiabilité** : moins de dérives entre serveurs
- ✅ **Reproductibilité** : même image = même comportement
- ✅ **Déploiements simples** : processus prévisibles et automatisables
- ✅ **Rollback facile** : retour arrière en cas de problème
- ✅ **Traçabilité** : meilleure traçabilité des versions déployées

---

## 7. Dockerfile : rôle et philosophie

### À quoi sert un Dockerfile

Un Dockerfile est un fichier de configuration qui décrit, étape par étape, comment construire une image Docker. Il définit l'environnement, les dépendances, les fichiers à copier et la commande de démarrage de l'application.

Le Dockerfile permet d'automatiser la création d'images et de garantir que l'image sera construite de la même manière, quel que soit l'environnement.

### Processus de construction d'un Dockerfile

![Processus Dockerfile - Flux décisionnel](./Photos/DockerRun.avif)

**Le diagramme montre :**
- Le **processus décisionnel** de construction d'une image
- L'ordre des étapes (FROM → BUILD → RUN)
- Les choix clés : **CMD** vs **ENTRYPOINT** pour définir la commande par défaut
- La boucle itérative (ajouter plus de commandes RUN selon les besoins)

### En quoi c'est différent d'un script d'installation classique

Un script d'installation classique sert généralement à configurer une machine existante (installer des paquets, modifier le système en place). Il dépend souvent de l'état initial du serveur.

Un Dockerfile, lui, décrit la construction d'une image complète et isolée, à partir d'une image de base. Il ne modifie pas un système existant : il fabrique un nouvel artefact à chaque build.

Cela permet d'éviter les différences entre environnements et les effets de bord.

### Pourquoi on cherche à faire des images

**Images petites**

On cherche à faire des images petites pour :

- Réduire le temps de téléchargement
- Accélérer les déploiements
- Diminuer l'espace de stockage
- Réduire la surface d'attaque en sécurité

**Images reproductibles**

Des images reproductibles garantissent que :

- Un même Dockerfile produit la même image
- Les environnements sont cohérents entre dev, test et prod
- Les bugs liés aux différences d'environnement sont réduits

**Images prévisibles**

Des images prévisibles permettent de :

- Savoir exactement ce qui est déployé
- Éviter les comportements différents d'une machine à l'autre
- Faciliter le diagnostic et les retours arrière (rollback)

### Ce que signifie "une image est un artefact"

Dire qu'une image est un artefact signifie qu'elle est un livrable versionné, au même titre qu'un binaire, un package ou une archive. C'est un objet concret, stocké dans un registry, identifié par un tag ou un hash, et utilisé tel quel pour les déploiements.

L'image devient donc l'unité de livraison de l'application.

---

## 8. Les images "alpine", "slim", "distroless", "scratch"

### Ce que sont ces types d'images

Ces images sont des images de base Docker conçues pour fournir différents niveaux de minimalisme. Elles servent de point de départ pour construire des images applicatives, avec plus ou moins de composants système.

Elles représentent différents compromis entre taille, compatibilité, simplicité et sécurité.

### Leurs différences philosophiques et techniques

**Alpine :** distribution Linux très minimaliste basée sur musl libc, conçue pour être extrêmement légère.

**Slim :** version allégée d'une distribution classique (comme Debian slim), avec moins de paquets mais un environnement standard.

**Distroless :** images sans gestionnaire de paquets ni shell, contenant uniquement l'application et ses dépendances runtime.

**Scratch :** image totalement vide, sans OS, utilisée pour copier uniquement un binaire statique.

### Les avantages et inconvénients de chacune

#### Alpine

**Avantages :**
- ✅ Très petite taille
- ✅ Démarrage rapide
- ✅ Bonne pour réduire le poids des images

**Inconvénients :**
- ❌ Utilise musl (pas glibc), ce qui peut poser des problèmes de compatibilité
- ❌ Debug plus difficile
- ❌ Certains outils manquent par défaut

#### Slim

**Avantages :**
- ✅ Bon compromis entre légèreté et compatibilité
- ✅ Environnement proche d'une vraie distro
- ✅ Plus simple pour le debug

**Inconvénients :**
- ❌ Plus lourde qu'Alpine
- ❌ Contient plus de composants inutiles pour certaines apps

#### Distroless

**Avantages :**
- ✅ Très sécurisée (pas de shell, pas de package manager)
- ✅ Très petite surface d'attaque
- ✅ Très adaptée à la production

**Inconvénients :**
- ❌ Très difficile à debugger
- ❌ Moins flexible
- ❌ Nécessite une bonne maîtrise du build

#### Scratch

**Avantages :**
- ✅ Taille minimale possible
- ✅ Sécurité maximale
- ✅ Image ultra propre

**Inconvénients :**
- ❌ Pas de shell, pas de librairies
- ❌ Réservée aux binaires statiques
- ❌ Très peu flexible

### Dans quels cas les utiliser

**Alpine**

J'utiliserais Alpine pour :

- Des applications simples
- Des microservices légers
- Quand la taille de l'image est un critère important
- Des environnements de test ou de prod légers

**Slim**

J'utiliserais Slim pour :

- Des applications nécessitant une compatibilité standard Linux
- Des environnements où le debug est important
- Un bon compromis entre poids et confort

**Distroless**

J'utiliserais Distroless pour :

- Des applications en production
- Des services critiques
- Des environnements où la sécurité est prioritaire
- Des apps bien packagées et stables

**Scratch**

J'utiliserais Scratch pour :

- Des images ultra minimalistes
- Des besoins de sécurité maximale
- Des environnements très contrôlés

---

## 9. La persistance des données

### Pourquoi un conteneur ne doit pas contenir de données importantes en interne

Un conteneur est conçu pour être éphémère et jetable. Il peut être supprimé et recréé à tout moment dans une logique de déploiement.

Stocker des données importantes directement dans le système de fichiers interne du conteneur va à l'encontre de cette philosophie, car ces données sont liées à une instance temporaire. Cela rend les sauvegardes, les mises à jour et les redéploiements risqués.

### Ce qu'il se passe si on supprime un conteneur sans volume

Si un conteneur est supprimé sans utiliser de volume, toutes les données écrites dans son système de fichiers interne sont définitivement perdues. Cela inclut les fichiers générés par l'application, les logs, ou les données applicatives stockées localement.

Le conteneur étant détruit, son système de fichiers disparaît avec lui.

### Le rôle des volumes Docker

Les volumes Docker permettent de stocker les données en dehors du cycle de vie du conteneur. Ils sont gérés par Docker et montés dans le conteneur au moment de son exécution.

Les volumes permettent :

- De conserver les données même si le conteneur est supprimé
- De partager des données entre plusieurs conteneurs
- De faciliter les sauvegardes et les migrations

### Pourquoi base de données et uploads doivent toujours être externalisés

Les bases de données et les fichiers uploadés par les utilisateurs sont des données critiques. Ils doivent être stockés dans des volumes, des services externes (S3, NAS, stockage cloud) ou des bases de données managées.

Cela permet :

- D'assurer la persistance des données
- De faciliter les sauvegardes
- De permettre les redéploiements sans perte de données
- D'améliorer la fiabilité et la scalabilité de l'infrastructure

---

## 10. Les réseaux Docker (conceptuellement)

### Pourquoi Docker isole le réseau par défaut

Docker isole le réseau par défaut afin de séparer les conteneurs du réseau de la machine hôte et des autres conteneurs. Cette isolation permet d'améliorer la sécurité, d'éviter les conflits de ports et de mieux contrôler les communications entre services.

Chaque conteneur dispose ainsi de sa propre interface réseau virtuelle.

### Les modes réseau Docker

![Les 3 modes réseau Docker : Bridge, None, Host](./Photos/DockerReseau.png)

**Visualisation :**
- **Bridge (bleu)** : réseau isolé avec docker0, conteneurs avec IPs 172.17.x.x
- **None (orange)** : conteneur sans aucune connectivité réseau
- **Host (rose)** : conteneur accédant directement aux ports de l'hôte (port 5000)

### À quoi sert un réseau bridge

Un réseau bridge permet de connecter plusieurs conteneurs sur un même réseau virtuel privé. Les conteneurs peuvent communiquer entre eux via leurs noms, tout en restant isolés du réseau externe.

C'est le mode le plus utilisé pour faire communiquer des services (par exemple une application et une base de données) sur une même machine.

### À quoi sert un réseau host

Un réseau host supprime l'isolation réseau entre le conteneur et la machine hôte. Le conteneur utilise directement la pile réseau de l'hôte.

Cela permet :

- D'éviter la traduction de ports
- D'avoir de meilleures performances réseau
- Mais au prix d'une isolation et d'une sécurité réduites

### À quoi sert un réseau none

Un réseau none désactive totalement le réseau du conteneur. Le conteneur n'a aucune connectivité réseau.

Ce mode est utilisé pour :

- Des tâches qui ne nécessitent aucun accès réseau
- Des raisons de sécurité
- Des traitements totalement isolés

### Pourquoi on utilise presque toujours des réseaux bridge personnalisés en production

On utilise généralement des réseaux bridge personnalisés en production car ils permettent :

- Une isolation claire entre groupes de services
- Une résolution de noms DNS entre conteneurs
- Un meilleur contrôle des flux réseau
- Une configuration plus propre et plus sécurisée
- Une architecture plus proche de la production réelle

Ils offrent un bon compromis entre isolation, sécurité, flexibilité et simplicité.

---

## 11. Sécurité et cloisonnement

### Pourquoi il est dangereux d'exposer une base de données directement

Exposer une base de données directement sur Internet augmente fortement les risques de sécurité. Cela permet à des attaquants de tenter des connexions, des attaques par force brute, ou d'exploiter des vulnérabilités du moteur de base de données.

Une base de données doit normalement être accessible uniquement par les applications qui en ont besoin, sur un réseau interne, et non directement depuis l'extérieur.

### Ce que permet l'isolation réseau Docker

L'isolation réseau Docker permet de créer des réseaux privés entre conteneurs. Seuls les conteneurs connectés au même réseau peuvent communiquer entre eux.

Cela permet :

- De limiter l'exposition des services sensibles
- De contrôler quels services peuvent se parler
- De réduire la surface d'attaque
- De segmenter l'architecture (frontend, backend, base de données)

### Ce que permet network: none

Le mode `network: none` permet de lancer un conteneur sans aucune connectivité réseau. Le conteneur est totalement isolé du réseau, ce qui empêche toute communication entrante ou sortante.

Ce mode est utile pour :

- Des traitements batch
- Des outils de calcul
- Des tâches qui ne doivent pas accéder au réseau
- Renforcer la sécurité par isolement total

### En quoi Docker est un outil de confinement autant que de déploiement

Docker ne sert pas uniquement à déployer des applications, mais aussi à les confiner. Grâce à l'isolation des processus, du système de fichiers et du réseau, Docker limite l'impact d'une application compromise.

Cela permet :

- ✅ De réduire les privilèges
- ✅ D'isoler les services entre eux
- ✅ De limiter les dégâts en cas de faille
- ✅ D'appliquer le principe du moindre privilège

Docker agit donc comme une **couche de confinement**, en plus d'être un outil de déploiement.

---

## 12. Architecture en services et microservices

### En quoi Docker pousse naturellement vers une architecture en services

Docker pousse naturellement vers une architecture en services, car chaque conteneur est conçu pour exécuter un processus ou un service principal. Cela encourage à découper une application en plusieurs composants indépendants (API, frontend, base de données, workers, etc.), chacun dans son propre conteneur.

Cette approche favorise une organisation proche des microservices ou, au minimum, d'une architecture en services.

### Ce que ça change dans la manière de concevoir une application

Avec Docker, on ne conçoit plus une application comme un seul bloc monolithique. On pense en termes de services indépendants, avec :

- Des responsabilités bien définies
- Des interfaces claires (API, ports, protocoles)
- Des dépendances explicites entre services

Cela pousse à mieux séparer les couches (frontend, backend, data, traitements), et à formaliser les échanges entre composants.

### Les avantages et inconvénients de cette approche

#### Avantages

- ✅ **Modularité** : meilleure organisation du code
- ✅ **Déploiement indépendant** : chaque service peut être mis à jour seul
- ✅ **Scalabilité** : possibilité de scaler les services indépendamment
- ✅ **Isolation des pannes** : une panne n'impacte qu'un service
- ✅ **Technologies variées** : chaque service peut utiliser sa technologie

#### Inconvénients

- ❌ **Complexité accrue** : architecture plus difficile à comprendre
- ❌ **Gestion du réseau** : communication entre services plus complexe
- ❌ **Observabilité** : logs, monitoring et tracing plus exigeants
- ❌ **Déploiement** : orchestration et gestion des dépendances plus complexes

### Pourquoi Docker n'est pas juste "un outil de dev" mais un outil d'architecture

Docker ne sert pas uniquement à faciliter le développement local. Il influence directement la façon dont les applications sont conçues, découpées et déployées.

En standardisant les environnements et en favorisant le découpage en services, Docker devient un **outil structurant** de l'architecture logicielle. Il impacte les choix techniques, l'organisation des équipes et les stratégies de déploiement.

Docker est donc autant un **outil d'architecture** qu'un outil de développement.

---

## 🎓 Conclusion

1. **Conteneur vs VM** : à choisir selon le besoin d'isolation
2. **Image vs Conteneur** : modèle vs instance en exécution
3. **Build vs Run** : fabrication vs déploiement
4. **Layers** : optimisation et cache pour les images
5. **Registry** : partage centralisé des images en équipe
6. **Infrastructure immuable** : déploiements fiables et reproductibles
7. **Dockerfile** : automatisation de la création d'images
8. **Variantes d'images** : choix selon les contraintes
9. **Persistance** : gestion des données critiques
10. **Réseaux** : isolation et communication entre conteneurs
11. **Sécurité** : cloisonnement et confinement des applications
12. **Architecture** : impact sur la conception d'applications modernes

